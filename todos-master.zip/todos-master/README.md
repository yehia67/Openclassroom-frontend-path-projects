# Project 8 for Frontend Path by Openclassrooms.com
Task description:
1. Add new unit test with Jasmine Framework
2. Write technical documentation

You can find tested app here: 
https://kpochojka.github.io/todoapp/

You can find documentation here:
https://kpochojka.github.io/doc-todos/

To run the unit jasmine test follow steps below:
1. Download whole respository.
2. Open SpecRunner.html in your browser, which you'll find in the /test folder.

You can also run the tests in the terminal, by installing jasmine locally and globaly.

