import React from 'react';
import logo from '../logo2.png'
class Footer extends React.Component {
  render() {
    return (
      <footer className="page-footer font-small mt-5" style={{backgroundColor: "#666666"}}>

    <div className="footer-copyright text-center py-3">© 2019 Copyright:
      <a href="#"> YEHIA TAREK</a>
    </div>


  </footer>

    );
  }
}

export default Footer;
